from setuptools import setup, find_packages

setup(
    name = 'edgeP',
    version = '0.0.1',
    keywords='GSEA',
    description = '',
    license = 'MIT License',
    url = 'https://github.com/Gutier14/CAAFinder',
    author = 'YISHEN WANG',
    author_email = 'wangysh23@mail2.sysu.edu.cn',
    packages = find_packages(),
    include_package_data = True,
    platforms = 'any',
    install_requires = [],
)